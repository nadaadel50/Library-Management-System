﻿namespace librarysystem
{


    partial class DataSet1
    {
    }
}

namespace librarysystem.DataSet1TableAdapters {
    
    
    public partial class STUDENTTableAdapter {
    }
}
