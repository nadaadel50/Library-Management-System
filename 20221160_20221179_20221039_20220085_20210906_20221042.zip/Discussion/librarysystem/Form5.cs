﻿using Microsoft.Reporting.WinForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace librarysystem
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();
            InitializeReportViewer();

        }

        private void InitializeReportViewer()
        {
            reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            // Set ReportViewer properties as needed
            reportViewer1.Dock = DockStyle.Fill;

            // Add ReportViewer to the form's Controls collection
            this.Controls.Add(reportViewer1);
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
        SqlConnection connection = new SqlConnection("Data Source=DESKTOP-2F27L5N\\SQLEXPRESS;Initial Catalog=libraryManagementSystem;Integrated Security=True;");

        //SqlConnection connection = new SqlConnection("Data Source = DESKTOP-BC4G55R\\SQLEXPRESS;Initial Catalog=libraryManagementSystem;Integrated Security=True;");
        private void button1_Click(object sender, EventArgs e)
        {
            SqlCommand command = new SqlCommand("Select * from STUDENT ",connection);
            SqlDataAdapter d = new SqlDataAdapter(command);
            DataTable dt = new DataTable();
            d.Fill(dt);

            // reportViewer1.LocalReport.DataSources.Clear();
            //ReportDataSource source = new ReportDataSource("DataSet1",dt);

            //reportViewer1.LocalReport.ReportPath = @"C:\Users\WIN 10\Desktop\librarySystemBASE\librarysystem\Report1.rdlc";
            //reportViewer1.LocalReport.DataSources.Add(source);
            //reportViewer1.RefreshReport();
            ReportDataSource rds = new ReportDataSource("DataSet1", dt);
            reportViewer1.LocalReport.ReportPath = "Report1.rdlc";
            reportViewer1.LocalReport.DataSources.Clear();
            reportViewer1.LocalReport.DataSources.Add(rds);
            reportViewer1.RefreshReport();
        }

        private void Form5_Load(object sender, EventArgs e)
        {
                
        }
    }
}
